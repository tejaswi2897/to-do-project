let taskInput = document.getElementById('taskInput');
let taskList = document.getElementById('taskList');
let addTaskBtn = document.getElementById('taskAdd');

addTaskBtn.addEventListener('click', function(){
    if(taskInput.value === ''){
        alert("please write Something");
    }else{
        let list = document.createElement('li');
        list.innerHTML = taskInput.value;
        taskList.appendChild(list);
        let deleteTask = document.createElement("i");
        list.appendChild(deleteTask);
        deleteTask.classList.add("fa-solid");
        deleteTask.classList.add("fa-trash-can");
        deleteTask.classList.add("delete");
        let editTask = document.createElement("i");
        list.appendChild(editTask);
        editTask.classList.add("fa-solid");
        editTask.classList.add("fa-pen");
        editTask.classList.add("edit");
        taskInput.value = '';
    }
    
    saveData()
})
taskList.addEventListener('click', function(del){
    if(del.target.tagName === "LI"){
        del.target.classList.toggle('checked');
    }else if(del.target.classList.contains("delete")){
            del.target.parentElement.remove();
    }else if(del.target.classList.contains("edit")){
        let liElement = del.target.parentElement.innerText;
        taskInput.value = liElement;
        
    }
    saveData()
},false);

function saveData(){
    localStorage.setItem("data", taskList.innerHTML)
}
function showData(){
    taskList.innerHTML = localStorage.getItem("data");
}
showData();